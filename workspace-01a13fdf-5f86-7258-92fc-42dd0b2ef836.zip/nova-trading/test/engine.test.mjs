/* Test moteur : exécuté avec `node test/engine.test.mjs` */
import fs from 'fs';
import vm from 'vm';
import path from 'path';
import { fileURLToPath } from 'url';

const root = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
const files = ['js/util.js', 'js/sources.js', 'js/curriculum.js', 'js/market.js', 'js/indicators.js', 'js/broker.js'];

const sandbox = { console, Math, Date, JSON, Intl, localStorage: { getItem: () => null, setItem: () => { } } };
sandbox.window = sandbox;
sandbox.globalThis = sandbox;
vm.createContext(sandbox);
for (const f of files) vm.runInContext(fs.readFileSync(path.join(root, f), 'utf8'), sandbox, { filename: f });

const Nova = vm.runInContext('Nova', sandbox);
const SOURCES = vm.runInContext('SOURCES', sandbox);
const CONCEPTS = vm.runInContext('CONCEPTS', sandbox);
const LESSONS = vm.runInContext('LESSONS', sandbox);
let failures = 0;
const ok = (cond, msg, extra = '') => {
  if (!cond) { failures++; console.log('  ✗ ' + msg + (extra ? '  → ' + extra : '')); }
  else console.log('  ✓ ' + msg + (extra ? '  → ' + extra : ''));
};

console.log('\n1. Génération du marché (NEO-EU, 1m)');
const m = new Nova.Market('neo', 42);
m.warmup('1d', 40);
console.log('   minutes simulées :', m.tickCount.toLocaleString('fr-FR'));
for (const tf of Nova.TIMEFRAMES) {
  const s = m.series[tf.key];
  const bad = s.filter(c => !isFinite(c.o) || !isFinite(c.h) || !isFinite(c.l) || !isFinite(c.c) || c.h < c.l || c.h < Math.max(c.o, c.c) || c.l > Math.min(c.o, c.c));
  ok(s.length > 30 && bad.length === 0, `${tf.key} : ${s.length} bougies, OHLC cohérent`, bad.length ? bad.length + ' bougies invalides' : '');
}

const all = m.series['1m'];
const rets = [];
for (let i = 1; i < all.length; i++) rets.push(Math.log(all[i].c / all[i - 1].c));
const mean = rets.reduce((a, b) => a + b, 0) / rets.length;
const sd = Math.sqrt(rets.reduce((a, b) => a + (b - mean) ** 2, 0) / rets.length);
const kurt = rets.reduce((a, b) => a + ((b - mean) / sd) ** 4, 0) / rets.length;
ok(sd * Math.sqrt(1440) > 0.004 && sd * Math.sqrt(1440) < 0.04, 'volatilité quotidienne réaliste', (sd * Math.sqrt(1440) * 100).toFixed(2) + ' %');
ok(kurt > 3.1, 'queues épaisses (kurtosis > 3, Mandelbrot 1963)', 'kurtosis = ' + kurt.toFixed(2));

/* regroupement de volatilité : autocorrélation des carrés de rendements */
const r2 = rets.map(r => r * r);
const m2 = r2.reduce((a, b) => a + b, 0) / r2.length;
let cov = 0, v = 0;
for (let i = 0; i < r2.length - 1; i++) cov += (r2[i] - m2) * (r2[i + 1] - m2);
cov /= r2.length;
for (let i = 0; i < r2.length; i++) v += (r2[i] - m2) ** 2;
v /= r2.length;
const acf1 = cov / v;
/* n ≈ 4200 → erreur-type ≈ 0,015 ; une acf > 0,15 est très largement significative */
ok(acf1 > 0.15, 'regroupement de volatilité (acf(r²) lag 1 nettement > 0)', 'acf = ' + acf1.toFixed(3));

console.log('\n2. Aucun regard vers le futur');
const m2m = new Nova.Market('xau', 7);
m2m.warmup('15m', 60);
const before = m2m.series['15m'].length;
const view = m2m.view('15m', 40);
ok(view.candles.length === 40 && view.candles.every(c => c.t < m2m.now()), 'la vue ne contient que des bougies passées');
ok(m2m.series['15m'].length === before, 'la lecture ne fait pas avancer le marché');
const lastClosed = m2m.series['15m'][m2m.series['15m'].length - 1];
m2m.advance('15m');
const newLast = m2m.series['15m'][m2m.series['15m'].length - 1];
ok(newLast.t > lastClosed.t, 'advance() clôture bien une nouvelle bougie');

console.log('\n3. Indicateurs');
const ctx = Nova.ind.context(m.series['15m'].slice(-400), { k: 3 });
ok(ctx && isFinite(ctx.a) && ctx.a > 0, 'ATR calculé', 'ATR = ' + ctx.a.toFixed(2));
ok(ctx.rsiV >= 0 && ctx.rsiV <= 100, 'RSI dans [0,100]', 'RSI = ' + ctx.rsiV.toFixed(1));
ok(ctx.levels.length >= 0 && ctx.levels.every(z => isFinite(z.p)), 'zones de support/résistance', ctx.levels.length + ' zones');
ok(['up', 'down', 'flat'].includes(ctx.trend), 'structure détectée', ctx.trend + ' (' + ctx.structure.note + ')');
ok(typeof ctx.volState === 'string', 'état de volatilité', ctx.volState);

console.log('\n4. Régimes (5 marchés indépendants)');
const seen = {};
for (let s = 0; s < 5; s++) {
  const mm = new Nova.Market('neo', 1000 + s);
  mm.warmup('1d', 25);
  mm.regimeLog.forEach(r => { seen[r.regime] = (seen[r.regime] || 0) + 1; });
}
const total = Object.values(seen).reduce((a, b) => a + b, 0);
ok(Object.keys(seen).length >= 5, 'au moins 5 régimes rencontrés', JSON.stringify(seen));
ok(total > 100, 'transitions nombreuses', total + ' changements de régime');

console.log('\n5. Compte & exécution');
const m3 = new Nova.Market('neo', 99);
m3.warmup('15m', 80);
const b = new Nova.Broker(m3.inst, 10000);
const px = m3.ask();
const sl = px - 12, tp = px + 24;
const sized = b.sizeForRisk(1, px, sl, m3);
ok(sized.size > 0, 'taille calculée pour 1 % de risque', sized.size + ' contrats → risque ' + sized.riskCash.toFixed(2) + ' €');
const fills = [];
b.on('fill', p => fills.push(p));
const closes = [];
b.on('close', r => closes.push(r));
const pos = b.place(m3, { kind: 'market', side: 'buy', size: sized.size, sl, tp, reason: 'test', tf: '15m', bar: 0, ctx: null });
ok(!!pos && pos.entry >= px, 'ordre au marché exécuté à l\'ask + slippage', 'ask ' + px.toFixed(2) + ' → fill ' + pos.entry.toFixed(2));
ok(b.cash < 10000, 'commission prélevée à l\'entrée', (10000 - b.cash).toFixed(2) + ' €');
ok(b.positions.length === 1 && b.marginUsed() > 0, 'marge immobilisée', b.marginUsed().toFixed(2) + ' €');

for (let i = 0; i < 400 && b.positions.length; i++) { m3.advance('15m'); b.tick(m3); }
ok(closes.length === 1, 'position clôturée par SL ou TP', closes.length ? 'sortie = ' + closes[0].reason : 'toujours ouverte');
const rec = closes[0];
ok(isFinite(rec.pnl) && isFinite(rec.R), 'enregistrement journalisé', 'P&L ' + rec.pnl.toFixed(2) + ' € / ' + rec.R.toFixed(2) + ' R');
if (rec.reason === 'sl') ok(rec.R < 0 && rec.R > -1.6, 'perte bornée autour de −1 R', rec.R.toFixed(2) + ' R');
if (rec.reason === 'tp') ok(rec.R > 0, 'gain supérieur à 0', rec.R.toFixed(2) + ' R');
ok(b.positions.length === 0 && b.cash > 9000 && b.cash < 11000, 'trésorerie cohérente', b.cash.toFixed(2) + ' €');
ok(b.totalCommission > 0, 'coûts comptabilisés', 'commissions ' + b.totalCommission.toFixed(2) + ' € · slippage ' + b.totalSlippage.toFixed(2) + ' €');

console.log('\n6. Ordres en attente');
const m4 = new Nova.Market('neo', 555);
m4.warmup('15m', 60);
const b2 = new Nova.Broker(m4.inst, 10000);
const lim = b2.place(m4, { kind: 'limit', side: 'buy', size: 1, price: m4.bid() + m4.inst.tick, sl: m4.mid - 20, tf: '15m', bar: 0 });
ok(b2.orders.length === 1 && b2.positions.length === 0, 'ordre limite en attente');
let n = 0;
while (b2.orders.length && n++ < 500) { m4.advance('15m'); b2.tick(m4); }
ok(b2.positions.length === 1 || n >= 500, 'ordre limite exécuté au franchissement', 'après ' + n + ' bougies');
if (b2.positions.length) ok(b2.positions[0].entry <= lim.price + 0.01, 'exécution au prix limite ou mieux', b2.positions[0].entry.toFixed(2) + ' ≤ ' + lim.price.toFixed(2));
const stop = b2.place(m4, { kind: 'stop', side: 'sell', size: 1, price: m4.mid + 6, tf: '15m', bar: 0 });
ok(b2.orders.some(o => o.id === stop.id), 'ordre stop accepté au-dessus du marché');

console.log('\n7. Modification de stop suivie');
const p0 = b2.positions[0];
b2.modify(p0, { sl: p0.entry - 30 }, m4, 10);
ok(p0.stopMoves.length === 1 && p0.stopMoves[0].dir === 'worse', 'élargissement de stop détecté', JSON.stringify(p0.stopMoves[0].dir));

console.log('\n8. Espérance et cohérence du registre de sources');
const concepts = CONCEPTS;
ok(concepts.length >= 20, 'bibliothèque de concepts', concepts.length + ' concepts');
const missing = [];
concepts.forEach(c => (c.sources || []).forEach(s => { if (!SOURCES[s]) missing.push(c.id + '→' + s); }));
ok(missing.length === 0, 'chaque concept cite une source existante', missing.join(', ') || 'aucune référence manquante');
const noUrl = Object.entries(SOURCES).filter(([k, v]) => !/^https?:\/\//.test(v.url)).map(([k]) => k);
ok(noUrl.length === 0, 'toutes les sources ont une URL vérifiable', noUrl.join(', ') || 'OK');
const lessons = LESSONS;
const badLesson = lessons.filter(l => !concepts.some(c => c.id === l.concept));
ok(badLesson.length === 0, 'chaque leçon renvoie à un concept', badLesson.map(l => l.id).join(', ') || 'OK');

console.log(failures === 0 ? '\n✔ Tous les tests passent.\n' : `\n✘ ${failures} échec(s).\n`);
process.exit(failures ? 1 : 0);
